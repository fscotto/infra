# 🐞 Debug Session

## Problema
Descrizione bug.

## Riproduzione
```bash
./app
```

## Analisi
- breakpoint:
- stack:
- registri:

## Root Cause
-

## Fix
-

## Note
-
