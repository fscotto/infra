#!/usr/bin/env python3

import sys


def main():
    print("Starting script...")


if __name__ == "__main__":
    main()
