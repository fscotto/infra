# {{TITLE}}

## Contesto
Breve descrizione del problema / scenario.

## Obiettivo
Cosa voglio ottenere.

## Ambiente
- OS:
- Toolchain:
- Versioni:

## Procedura
1.
2.
3.

## Note
- 

## Problemi incontrati
- 

## Soluzione finale
