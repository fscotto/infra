#!/bin/sh
set -eu

usage() {
    echo "Usage: $0 [args]" >&2
    exit 1
}

main() {
    echo "Starting script..."

    # TODO
}

main "$@"
