# 📚 Study Log - {{DATE}}

## Argomento
-

## Fonte
- Libro:
- Capitolo:

## Concetti chiave
- 
- 

## Codice scritto
```c

```

## Problemi
- 

## Soluzioni
- 

## Cosa approfondire
- 
