# {{PROJECT_NAME}}

## Descrizione
Breve descrizione del progetto.

## Features
- 
- 

## Requisiti
- 

## Installazione
```bash
git clone ...
cd ...
make
```

## Utilizzo
```bash
./app
```

## Struttura
```
.
├── src/
├── include/
├── Makefile
```

## TODO
- [ ] 

## Licenza
MIT
